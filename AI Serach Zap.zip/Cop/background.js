// background.js - MV3 service worker
// DWELL minutes default 3 (change TEST_MODE below for quick testing)
const API_KEY = "AIzaSyBwNHhBC7IKitdpn6iwY9hzje1FOSmU9Gg"; // as requested
const MODEL_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`;

const DWELL_MINUTES = 3;       // dwell time on external site (minutes) - final value
const SESSION_MINUTES = 30;    // session duration (minutes)

// For quick debugging set TEST_MODE = true, TEST_DWELL_SEC = 10
const TEST_MODE = false;
const TEST_DWELL_SEC = 10;

let state = {
  running: false,
  sessionStartedAt: null,
  sessionEndsAt: null,
  currentTabId: null,        // tab used for search and navigation
  activeVisit: null,         // { tabId, href, domain, startedAt }
  visitCount: 0,
  visitedDomains: [],        // domains to avoid repetition
  lastQuery: ""
};

function log(...args) { console.log("[AI-SEQ]", ...args); }
function saveState() { chrome.storage.local.set({ ai_seq_state: state }, ()=>{}); }
async function loadState() { const s = await chrome.storage.local.get("ai_seq_state"); if (s.ai_seq_state) state = s.ai_seq_state; }

// --- Query generation ---
async function generateQueryViaAI() {
  // strict prompt: Russian, 1-3 words, no city/country
  const prompt = `Сгенерируй короткий поисковый запрос строго на русском языке (1–3 слова), без указания города, страны или региона.
Если тема — "погода", верни только слово "погода".
Если тема — "снять квартиру", верни только "снять квартиру".
Дай ровно один запрос без пояснений.`;
  try {
    const body = { contents: [{ parts: [{ text: prompt }] }] };
    const resp = await fetch(MODEL_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await resp.json();
    let text = "";
    if (data?.candidates?.[0]?.content?.parts?.[0]?.text) {
      text = data.candidates[0].content.parts[0].text;
    } else if (data?.output_text) {
      text = data.output_text;
    } else {
      // try stringify fallback
      text = JSON.stringify(data || "").slice(0,200);
    }
    text = text.trim().replace(/\s+/g," ").split(/[.,;!]/)[0].slice(0,80).trim();
    if (!text || !/[А-Яа-яЁё]/.test(text)) throw new Error("AI returned invalid");
    return text;
  } catch (e) {
    log("AI generation failed:", e && e.message ? e.message : e);
    throw e;
  }
}

function generateQueryFallback() {
  const topics = ["погода","снять квартиру","новости","работа","ресторан","кино","спорт","афиша","ремонт","техника"];
  return topics[Math.floor(Math.random()*topics.length)];
}

async function generateQuery() {
  try {
    const q = await generateQueryViaAI();
    state.lastQuery = q;
    saveState();
    return q;
  } catch (e) {
    const q = generateQueryFallback();
    state.lastQuery = q;
    saveState();
    return q;
  }
}

// --- Tab helpers ---
function createTab(url) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url }, (tab) => {
      if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
      resolve(tab);
    });
  });
}

// --- Core flow ---
async function openSearchTab() {
  if (!state.running) return;
  // close previous search tab if left
  if (state.currentTabId) {
    try { await chrome.tabs.remove(state.currentTabId); } catch (e) {}
    state.currentTabId = null;
  }
  const q = await generateQuery();
  const url = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
  log("Opening search for:", q);
  try {
    const tab = await createTab(url);
    state.currentTabId = tab.id;
    saveState();
  } catch (e) {
    log("Failed to create search tab:", e);
  }
}

function startSession() {
  if (state.running) return;
  state.running = true;
  state.sessionStartedAt = Date.now();
  state.sessionEndsAt = state.sessionStartedAt + SESSION_MINUTES*60*1000;
  state.visitCount = 0;
  state.visitedDomains = [];
  state.currentTabId = null;
  state.activeVisit = null;
  state.lastQuery = "";
  saveState();
  openSearchTab();
  log("Session started; will run until", new Date(state.sessionEndsAt).toString());
}

function stopSession() {
  state.running = false;
  // clear alarms
  chrome.alarms.clear("dwell");
  // close tabs we own
  if (state.currentTabId) { try { chrome.tabs.remove(state.currentTabId); } catch (e) {} state.currentTabId = null; }
  if (state.activeVisit && state.activeVisit.tabId) { try { chrome.tabs.remove(state.activeVisit.tabId); } catch (e) {} state.activeVisit = null; }
  saveState();
  log("Session stopped");
}

// --- Message handler ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;
  if (message.type === "START") {
    startSession();
    sendResponse({ ok:true });
    return;
  }
  if (message.type === "STOP") {
    stopSession();
    sendResponse({ ok:true });
    return;
  }
  if (message.type === "REQUEST_STATE") {
    sendResponse({ state });
    return;
  }
  if (message.type === "ORGANIC_LINKS") {
    // choose first link whose domain not yet visited
    const links = Array.isArray(message.links) ? message.links : [];
    if (!state.running || links.length === 0) {
      sendResponse({ action: "NO_LINKS" });
      return;
    }
    let chosenIndex = -1;
    for (let i=0;i<links.length;i++) {
      try {
        const u = new URL(links[i].href, "https://www.google.com");
        const domain = u.hostname.replace(/^www\./,"").toLowerCase();
        if (!state.visitedDomains.includes(domain)) {
          chosenIndex = i;
          break;
        }
      } catch (e) { continue; }
    }
    if (chosenIndex === -1) chosenIndex = 0;
    const chosen = links[chosenIndex];
    // background will wait for WILL_NAVIGATE message before starting dwell alarm.
    log("Selected link", chosen.href, "index", chosenIndex);
    sendResponse({ action: "NAVIGATE", index: chosenIndex, href: chosen.href });
    return;
  }
  if (message.type === "WILL_NAVIGATE") {
    // content-script tells us it's about to navigate current search tab to href
    if (!state.running) { sendResponse({ ok:false, reason:"not running" }); return; }
    const href = message.href;
    try {
      const u = new URL(href, "https://www.google.com");
      const domain = u.hostname.replace(/^www\./,"").toLowerCase();
      // Register visited domain
      if (!state.visitedDomains.includes(domain)) state.visitedDomains.push(domain);
      // Active visit: in same tab we opened for search
      const tabId = state.currentTabId;
      state.activeVisit = { tabId: tabId, href: href, domain: domain, startedAt: Date.now() };
      // Set dwell alarm
      chrome.alarms.clear("dwell");
      const delayMin = TEST_MODE ? (TEST_DWELL_SEC/60) : DWELL_MINUTES;
      chrome.alarms.create("dwell", { delayInMinutes: delayMin });
      saveState();
      log("WILL_NAVIGATE hooked. Dwell alarm set for", delayMin, "minutes, for tab", tabId);
      sendResponse({ ok:true });
    } catch (e) {
      log("WILL_NAVIGATE: invalid href", href, e);
      sendResponse({ ok:false, err:String(e) });
    }
    return true; // indicate async response maybe
  }
});

// tabs.onUpdated as backup: if the tab changed URL to non-google, ensure we have activeVisit
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!state.running) return;
  if (!tab || !tab.url) return;
  // If this is our search tab and it navigated away from google search to external url, ensure activeVisit is set
  if (tabId === state.currentTabId && changeInfo.status === "complete" && !tab.url.includes("google.com/search")) {
    const href = tab.url;
    try {
      const u = new URL(href);
      const domain = u.hostname.replace(/^www\./,"").toLowerCase();
      if (!state.visitedDomains.includes(domain)) state.visitedDomains.push(domain);
      state.activeVisit = { tabId: tabId, href: href, domain: domain, startedAt: Date.now() };
      // set dwell alarm if not already
      chrome.alarms.get("dwell", (a) => {
        if (!a) {
          const delayMin = TEST_MODE ? (TEST_DWELL_SEC/60) : DWELL_MINUTES;
          chrome.alarms.create("dwell", { delayInMinutes: delayMin });
          saveState();
          log("tabs.onUpdated: created dwell alarm for", delayMin, "minutes");
        }
      });
    } catch (e) {}
  }
});

// alarm fired
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== "dwell") return;
  log("dwell alarm fired");
  (async () => {
    try {
      // close active visit tab if exists
      if (state.activeVisit && state.activeVisit.tabId) {
        try { await new Promise((res)=>chrome.tabs.remove(state.activeVisit.tabId, res)); } catch (e) { log("Error closing active tab:", e); }
        state.activeVisit = null;
      } else if (state.currentTabId) {
        // fallback: close currentTabId
        try { await new Promise((res)=>chrome.tabs.remove(state.currentTabId, res)); } catch (e) {}
        state.currentTabId = null;
      }
    } catch (e) {
      log("Error during dwell cleanup:", e);
    }
    state.visitCount = (state.visitCount||0) + 1;
    saveState();
    // Check session end
    if (Date.now() >= state.sessionEndsAt) {
      stopSession();
    } else if (state.running) {
      openSearchTab();
    }
  })();
});

// handle manual removal
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  if (state.currentTabId && tabId === state.currentTabId) state.currentTabId = null;
  if (state.activeVisit && tabId === state.activeVisit.tabId) state.activeVisit = null;
  saveState();
});

// initial load
loadState().then(()=>{ log("Background ready", state); });
