// content-google.js
// Runs on Google search results page. Collects organic links and asks background which to open.

(function(){
  const MAX_WAIT_MS = 10000;
  const POLL_MS = 300;

  function sleep(ms){ return new Promise(res=>setTimeout(res,ms)); }

  function collectOrganicLinks() {
    const links = [];
    const seen = new Set();
    // Prefer result anchors with h3 (titles)
    const anchors = Array.from(document.querySelectorAll('a h3')).map(h3 => h3.closest('a')).filter(Boolean);
    for (const a of anchors) {
      const href = a.href || a.getAttribute('href');
      if (!href) continue;
      if (href.startsWith('/')) continue;
      if (href.includes('google.com')) continue;
      if (seen.has(href)) continue;
      seen.add(href);
      links.push({ href, title: (a.innerText||a.title||'').trim() });
    }
    // fallback: look at #search a[href]
    if (links.length === 0) {
      const all = Array.from(document.querySelectorAll('#search a[href], #rso a[href]'));
      for (const a of all) {
        const href = a.href || a.getAttribute('href');
        if (!href) continue;
        if (href.startsWith('/')) continue;
        if (href.includes('google.com')) continue;
        if (seen.has(href)) continue;
        seen.add(href);
        links.push({ href, title: (a.innerText||a.title||'').trim() });
      }
    }
    return links;
  }

  async function waitForLinks(timeout=MAX_WAIT_MS) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const links = collectOrganicLinks();
      if (links.length > 0) return links;
      await sleep(POLL_MS);
    }
    return collectOrganicLinks();
  }

  async function main(){
    if (!location.hostname.includes("google.") || !location.pathname.includes("/search")) return;
    const links = await waitForLinks();
    // Send to background
    chrome.runtime.sendMessage({ type: "ORGANIC_LINKS", links }, (resp) => {
      try {
        if (!resp) return;
        if (resp.action === "NO_LINKS") return;
        if (resp.action === "NAVIGATE" && resp.href) {
          // tell background we're about to navigate (so it can start dwell alarm)
          chrome.runtime.sendMessage({ type: "WILL_NAVIGATE", href: resp.href }, (r) => {
            // now navigate in same tab (reliable)
            setTimeout(() => {
              try {
                window.location.href = resp.href;
              } catch (e) {
                // fallback: try to click the element
                const allAnchors = Array.from(document.querySelectorAll('a[href]')).filter(a=> {
                  const href = a.href || a.getAttribute('href');
                  return href && !href.startsWith('/') && !href.includes('google.com');
                });
                const idx = typeof resp.index === "number" ? resp.index : 0;
                if (allAnchors[idx]) allAnchors[idx].click();
              }
            }, 150);
          });
        }
      } catch (e) {
        console.error("content-google error:", e);
      }
    });
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    setTimeout(main, 400);
  } else {
    window.addEventListener("DOMContentLoaded", () => setTimeout(main, 400));
  }
})();
